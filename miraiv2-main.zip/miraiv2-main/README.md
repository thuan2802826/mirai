# fix lỗi command load
# bán full soucre deobf mirai 1.2.14
# nhận code lệnh theo yêu cầu nhưng code được hay không thì không biết
